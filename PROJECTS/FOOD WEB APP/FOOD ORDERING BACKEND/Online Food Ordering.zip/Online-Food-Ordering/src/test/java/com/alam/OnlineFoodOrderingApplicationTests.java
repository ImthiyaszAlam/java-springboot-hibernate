package com.alam;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnlineFoodOrderingApplicationTests {

	@Test
	void contextLoads() {
	}

}
